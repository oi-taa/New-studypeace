// Whiteboard.js
import React, { useRef, useState } from 'react';
import './Whiteboard.css';

const Whiteboard = () => {
    const canvasRef = useRef(null);
    const [drawing, setDrawing] = useState(false);

    const startDrawing = () => setDrawing(true);
    const stopDrawing = () => setDrawing(false);

    const draw = (event) => {
        if (!drawing) return;
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        ctx.lineTo(event.clientX - canvas.offsetLeft, event.clientY - canvas.offsetTop);
        ctx.stroke();
    };

    return (
        <div className="whiteboard">
            <h2>Whiteboard</h2>
            <canvas
                ref={canvasRef}
                onMouseDown={startDrawing}
                onMouseUp={stopDrawing}
                onMouseMove={draw}
                width="500"
                height="500"
            ></canvas>
        </div>
    );
};

export default Whiteboard;
