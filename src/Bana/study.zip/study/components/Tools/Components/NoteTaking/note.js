// NoteTaking.js
import React, { useState } from 'react';
import './NoteTaking.css';

const NoteTaking = () => {
    const [note, setNote] = useState('');

    const handleSave = () => {
        localStorage.setItem('note', note);
        alert('Note saved!');
    };

    return (
        <div className="note-taking">
            <h2>Note Taking</h2>
            <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Write your notes here..."
            ></textarea>
            <button onClick={handleSave}>Save Note</button>
        </div>
    );
};

export default NoteTaking;
