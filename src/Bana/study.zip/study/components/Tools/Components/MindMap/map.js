// MindMap.js
import React, { useState } from 'react';
import './MindMap.css';

const MindMap = () => {
    const [mindmap, setMindmap] = useState('');

    const handleMindmapChange = (e) => {
        setMindmap(e.target.value);
    };

    return (
        <div className="mind-map">
            <h2>Create Mind Map</h2>
            <textarea
                value={mindmap}
                onChange={handleMindmapChange}
                placeholder="Start creating your mind map..."
            ></textarea>
        </div>
    );
};

export default MindMap;
