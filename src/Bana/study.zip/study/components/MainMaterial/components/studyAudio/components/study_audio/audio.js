// StudyAudio.js
import React, { useState } from 'react';
import './StudyAudio.css';

const StudyAudio = () => {
    const [currentAudio, setCurrentAudio] = useState(null);

    const audios = [
        { title: 'Lecture 1: Introduction to Chemistry', file: 'lecture1.mp3' },
        { title: 'Lecture 2: Physics Fundamentals', file: 'lecture2.mp3' },
        // Add more audio files
    ];

    const handlePlay = (file) => {
        const audio = new Audio(file);
        if (currentAudio) currentAudio.pause(); // Pause the previous audio
        audio.play();
        setCurrentAudio(audio);
    };

    return (
        <div className="study-audio">
            <h2>Study Audio</h2>
            <ul>
                {audios.map((audio, index) => (
                    <li key={index}>
                        {audio.title}
                        <button onClick={() => handlePlay(audio.file)}>Play</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default StudyAudio;
