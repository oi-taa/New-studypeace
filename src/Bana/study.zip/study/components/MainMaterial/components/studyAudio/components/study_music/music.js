// StudyMusic.js
import React, { useState } from 'react';
import './StudyMusic.css';

const StudyMusic = () => {
    const [currentMusic, setCurrentMusic] = useState(null);

    const musicTracks = [
        { title: 'Calm Focus', file: 'calm-focus.mp3' },
        { title: 'Deep Study', file: 'deep-study.mp3' },
        { title: 'Nature Sounds', file: 'nature-sounds.mp3' },
        // Add more music tracks
    ];

    const handlePlay = (file) => {
        const music = new Audio(file);
        if (currentMusic) currentMusic.pause(); // Pause the previous track
        music.play();
        setCurrentMusic(music);
    };

    return (
        <div className="study-music">
            <h2>Study Music</h2>
            <ul>
                {musicTracks.map((track, index) => (
                    <li key={index}>
                        {track.title}
                        <button onClick={() => handlePlay(track.file)}>Play</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default StudyMusic;
