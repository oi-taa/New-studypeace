// StudyMaterials.js
import React from 'react';
import './StudyMaterials.css';

const StudyMaterials = () => {
    const materials = [
        { subject: 'Math', title: 'Calculus Notes', link: '#' },
        { subject: 'Science', title: 'Physics Chapter 1', link: '#' },
        // Add more materials
    ];

    return (
        <div className="study-materials">
            <h2>Study Materials</h2>
            <ul>
                {materials.map((material, index) => (
                    <li key={index}>
                        <a href={material.link}>{material.title} - {material.subject}</a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default StudyMaterials;
