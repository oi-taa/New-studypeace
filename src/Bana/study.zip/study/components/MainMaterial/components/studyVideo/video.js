// VideoLectures.js
import React from 'react';
import './VideoLectures.css';

const VideoLectures = () => {
    const lectures = [
        { title: 'Lecture 1: Introduction to Algebra', link: '#' },
        { title: 'Lecture 2: Basic Calculus', link: '#' },
        // Add more lectures
    ];

    return (
        <div className="video-lectures">
            <h2>Video Lectures</h2>
            <ul>
                {lectures.map((lecture, index) => (
                    <li key={index}>
                        <a href={lecture.link}>{lecture.title}</a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default VideoLectures;
