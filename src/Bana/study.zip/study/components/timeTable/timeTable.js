// TimeTable.js
import React from 'react';
import './TimeTable.css';

const TimeTable = () => {
    const schedule = [
        { day: 'Monday', subject: 'Math', time: '9:00 AM - 10:30 AM' },
        { day: 'Tuesday', subject: 'Science', time: '11:00 AM - 12:30 PM' },
        // Add more timetable entries
    ];

    return (
        <div className="timetable">
            <h2>Study Time Table</h2>
            <table>
                <thead>
                    <tr>
                        <th>Day</th>
                        <th>Subject</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    {schedule.map((entry, index) => (
                        <tr key={index}>
                            <td>{entry.day}</td>
                            <td>{entry.subject}</td>
                            <td>{entry.time}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TimeTable;
