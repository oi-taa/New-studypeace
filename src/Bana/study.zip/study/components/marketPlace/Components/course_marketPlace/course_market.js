// CourseMarketplace.js
import React from 'react';
import './CourseMarketplace.css';

const CourseMarketplace = () => {
    const courses = [
        { name: 'React Mastery', price: '$49.99' },
        { name: 'Advanced Data Science', price: '$79.99' },
        // Add more courses
    ];

    return (
        <div className="course-marketplace">
            <h2>Course Marketplace</h2>
            <ul>
                {courses.map((course, index) => (
                    <li key={index}>
                        {course.name} - {course.price}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default CourseMarketplace;
