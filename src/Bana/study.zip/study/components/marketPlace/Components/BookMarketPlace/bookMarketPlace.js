// BookMarketplace.js
import React from 'react';
import './BookMarketplace.css';

const BookMarketplace = () => {
    const books = [
        { title: 'Algorithms Unlocked', price: '$29.99' },
        { title: 'Artificial Intelligence: A Modern Approach', price: '$99.99' },
        // Add more books
    ];

    return (
        <div className="book-marketplace">
            <h2>Book Marketplace</h2>
            <ul>
                {books.map((book, index) => (
                    <li key={index}>
                        {book.title} - {book.price}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default BookMarketplace;
