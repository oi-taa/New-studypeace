// Subjects.js
import React from 'react';
import './Subjects.css';

const Subjects = () => {
    const subjects = ['Math', 'Science', 'History', 'English', 'Computer Science'];

    return (
        <div className="subjects">
            <h2>Your Subjects</h2>
            <ul>
                {subjects.map((subject, index) => (
                    <li key={index}>{subject}</li>
                ))}
            </ul>
        </div>
    );
};

export default Subjects;
