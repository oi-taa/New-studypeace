// ProfileDashboard.js
import React from 'react';
import './ProfileDashboard.css';

const ProfileDashboard = () => {
    return (
        <div className="profile-dashboard">
            <h2>User Profile</h2>
            <div className="profile-info">
                <p>Name: John Doe</p>
                <p>Current Subjects: 5</p>
                <p>Study Time This Week: 10 hours</p>
                <p>Progress: 70%</p>
            </div>
        </div>
    );
};

export default ProfileDashboard;
